package com.example.studytracker

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("study_tracker", Context.MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var summary: TextView
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        requestNotificationPermissionIfNeeded()
        buildScreen()
        scheduleDailyReminder()
        renderDashboard()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            setBackgroundColor(0xFFF5F7FB.toInt())
        }
        scroll.addView(root)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "STUDY TRACKER"
            textSize = 25f
            setTextColor(0xFF17365D.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 8)
        }
        root.addView(title)
        val subtitle = TextView(this).apply {
            text = "Lectures • Leçons • Révisions"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(0xFF526176.toInt())
            setPadding(0, 0, 0, 18)
        }
        root.addView(subtitle)

        summary = TextView(this).apply {
            textSize = 16f
            setTextColor(0xFF172033.toInt())
            setPadding(16, 16, 16, 16)
            setBackgroundColor(0xFFE4ECF7.toInt())
        }
        root.addView(summary)

        addButton("＋ Ajouter un livre") { showAddBookDialog() }
        addButton("＋ Ajouter une leçon") { showAddLessonDialog() }
        addButton("🔔 Activer le rappel quotidien (19 h)") {
            scheduleDailyReminder()
            Toast.makeText(this, "Rappel quotidien programmé pour 19 h.", Toast.LENGTH_LONG).show()
        }
        addButton("↻ Actualiser le tableau de bord") { renderDashboard() }

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 14, 0, 0)
        }
        root.addView(content)
    }

    private fun addButton(label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 7, 0, 7)
        root.addView(button, lp)
    }

    private fun renderDashboard() {
        val books = getArray("books")
        val lessons = getArray("lessons")
        val due = mutableListOf<JSONObject>()
        val today = dateString(Date())
        for (i in 0 until lessons.length()) {
            val item = lessons.optJSONObject(i) ?: continue
            if (item.optString("nextReview") <= today) due.add(item)
        }
        summary.text = "Aujourd'hui : ${dateString(Date())}\n" +
            "Livres : ${books.length()}  •  Leçons : ${lessons.length()}\n" +
            "Révisions à faire : ${due.size}"

        content.removeAllViews()
        addSectionTitle("MES LIVRES")
        if (books.length() == 0) addEmpty("Aucun livre enregistré.")
        for (i in 0 until books.length()) {
            val book = books.optJSONObject(i) ?: continue
            val total = book.optInt("totalPages", 1).coerceAtLeast(1)
            val current = book.optInt("currentPage", 0).coerceIn(0, total)
            val percent = (current * 100 / total)
            val card = makeCard("${book.optString("title")}\n$current / $total pages • $percent %")
            card.setOnClickListener { showUpdateBookDialog(i, book) }
            content.addView(card)
        }

        addSectionTitle("MES LEÇONS")
        if (lessons.length() == 0) addEmpty("Aucune leçon enregistrée.")
        for (i in 0 until lessons.length()) {
            val lesson = lessons.optJSONObject(i) ?: continue
            val title = lesson.optString("title")
            val subject = lesson.optString("subject")
            val score = lesson.optInt("score", -1)
            val next = lesson.optString("nextReview", "À planifier")
            val status = when {
                score < 0 -> "À évaluer"
                score < 70 -> "À retravailler"
                else -> "En révision"
            }
            val card = makeCard("$subject — $title\nRésultat : ${if (score < 0) "non évalué" else "$score %"} • $status\nProchaine révision : $next")
            card.setOnClickListener { showEvaluateLessonDialog(i, lesson) }
            content.addView(card)
        }
        val hint = TextView(this).apply {
            text = "\nConseil : touche une carte de livre pour mettre à jour les pages, ou une leçon pour enregistrer un score de révision."
            textSize = 13f
            setTextColor(0xFF526176.toInt())
        }
        content.addView(hint)
    }

    private fun addSectionTitle(text: String) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = 18f
            setTextColor(0xFF17365D.toInt())
            setPadding(0, 18, 0, 8)
        })
    }

    private fun addEmpty(text: String) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(0xFF68758A.toInt())
            setPadding(0, 4, 0, 8)
        })
    }

    private fun makeCard(textValue: String): TextView = TextView(this).apply {
        text = textValue
        textSize = 15f
        setTextColor(0xFF172033.toInt())
        setPadding(18, 18, 18, 18)
        setBackgroundColor(0xFFFFFFFF.toInt())
        elevation = 2f
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 5, 0, 8)
        layoutParams = lp
    }

    private fun showAddBookDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 0)
        }
        val title = editText("Titre du livre")
        val total = editText("Nombre total de pages", "100", true)
        val current = editText("Page actuelle", "0", true)
        box.addView(title); box.addView(total); box.addView(current)
        AlertDialog.Builder(this)
            .setTitle("Ajouter un livre")
            .setView(box)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Enregistrer") { _, _ ->
                val t = title.text.toString().trim()
                val pages = total.text.toString().toIntOrNull() ?: 0
                val page = current.text.toString().toIntOrNull() ?: 0
                if (t.isBlank() || pages < 1) {
                    toast("Indique un titre et un nombre de pages valide.")
                    return@setPositiveButton
                }
                val arr = getArray("books")
                arr.put(JSONObject().put("title", t).put("totalPages", pages).put("currentPage", page.coerceIn(0, pages)))
                saveArray("books", arr)
                renderDashboard()
            }.show()
    }

    private fun showUpdateBookDialog(index: Int, book: JSONObject) {
        val input = editText("Dernière page lue", book.optInt("currentPage", 0).toString(), true)
        AlertDialog.Builder(this)
            .setTitle(book.optString("title"))
            .setMessage("Saisis la dernière page atteinte.")
            .setView(input)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Mettre à jour") { _, _ ->
                val arr = getArray("books")
                val item = arr.optJSONObject(index) ?: return@setPositiveButton
                val total = item.optInt("totalPages", 1)
                item.put("currentPage", (input.text.toString().toIntOrNull() ?: 0).coerceIn(0, total))
                saveArray("books", arr)
                renderDashboard()
            }.show()
    }

    private fun showAddLessonDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 0)
        }
        val subject = editText("Matière (ex. Cardiologie)")
        val title = editText("Titre de la leçon")
        box.addView(subject); box.addView(title)
        AlertDialog.Builder(this)
            .setTitle("Ajouter une leçon")
            .setView(box)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Enregistrer") { _, _ ->
                val s = subject.text.toString().trim()
                val t = title.text.toString().trim()
                if (s.isBlank() || t.isBlank()) {
                    toast("Remplis la matière et le titre.")
                    return@setPositiveButton
                }
                val arr = getArray("lessons")
                arr.put(JSONObject()
                    .put("subject", s)
                    .put("title", t)
                    .put("score", -1)
                    .put("nextReview", dateString(Date()))
                    .put("lastStudy", ""))
                saveArray("lessons", arr)
                renderDashboard()
            }.show()
    }

    private fun showEvaluateLessonDialog(index: Int, lesson: JSONObject) {
        val input = editText("Résultat du QCM (0 à 100)", if (lesson.optInt("score", -1) < 0) "" else lesson.optInt("score").toString(), true)
        AlertDialog.Builder(this)
            .setTitle("Évaluer : ${lesson.optString("title")}")
            .setMessage("Enregistre ton score pour calculer la prochaine révision.")
            .setView(input)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Enregistrer") { _, _ ->
                val score = input.text.toString().toIntOrNull()
                if (score == null || score !in 0..100) {
                    toast("Le score doit être compris entre 0 et 100.")
                    return@setPositiveButton
                }
                val arr = getArray("lessons")
                val item = arr.optJSONObject(index) ?: return@setPositiveButton
                val interval = when {
                    score < 50 -> 1
                    score < 70 -> 2
                    score < 85 -> 7
                    else -> 14
                }
                val now = Date()
                val next = Calendar.getInstance().apply {
                    time = now
                    add(Calendar.DAY_OF_YEAR, interval)
                }.time
                item.put("score", score)
                item.put("lastStudy", dateString(now))
                item.put("nextReview", dateString(next))
                saveArray("lessons", arr)
                renderDashboard()
                toast("Prochaine révision : ${dateString(next)}")
            }.show()
    }

    private fun editText(hintText: String, value: String = "", numeric: Boolean = false): EditText =
        EditText(this).apply {
            hint = hintText
            setText(value)
            if (numeric) inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }

    private fun getArray(key: String): JSONArray =
        try { JSONArray(prefs.getString(key, "[]")) } catch (_: Exception) { JSONArray() }

    private fun saveArray(key: String, arr: JSONArray) {
        prefs.edit().putString(key, arr.toString()).apply()
    }

    private fun dateString(date: Date): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(date)

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("study_reminders", "Rappels d'étude", NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 200)
        }
    }

    private fun scheduleDailyReminder() {
        val intent = Intent(this, ReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            this, 1900, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 19)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.setInexactRepeating(
            AlarmManager.RTC_WAKEUP,
            calendar.timeInMillis,
            AlarmManager.INTERVAL_DAY,
            pending
        )
    }
}
