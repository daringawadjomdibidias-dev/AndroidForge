# Study Tracker (Android)

Projet Android natif de départ pour suivre les livres, les leçons et les révisions.

## Fonctionnalités incluses
- Ajout manuel de livres (pages totales, page actuelle).
- Ajout manuel de leçons (matière, titre, score de compréhension).
- Mise à jour de la progression des livres.
- Calcul de la prochaine révision selon le score.
- Rappel quotidien local à 19 h (l'utilisateur doit autoriser les notifications sur Android 13+).
- Données conservées localement dans les préférences de l'application.

## Construire l'APK
1. Installer Android Studio sur un ordinateur.
2. Ouvrir le dossier `StudyTrackerAndroid`.
3. Laisser Gradle synchroniser le projet.
4. Connecter un téléphone Android ou utiliser un émulateur.
5. Choisir **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio indiquera l'emplacement de l'APK généré.

Ce dossier est le code source du projet ; ce n'est pas encore un fichier APK compilé.
Le premier build nécessite une connexion Internet pour télécharger les dépendances Gradle/Android.

## Remarque sur les rappels
Les rappels sont planifiés localement à 19 h environ chaque jour. Android peut retarder les alarmes non exactes pour économiser la batterie. Autoriser les notifications dans les paramètres du téléphone.
